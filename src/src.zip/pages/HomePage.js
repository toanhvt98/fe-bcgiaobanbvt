import React from "react";
import Drawer from "@mui/material/Drawer";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import Collapse from "@mui/material/Collapse";
import { useState } from "react";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Fab from "@mui/material/Fab";
import MenuIcon from "@mui/icons-material/Menu";
import { Container, Typography } from "@mui/material";
import useMediaQuery from "@mui/material/useMediaQuery";

function HomePage() {
  const [open, setOpen] = useState(false);
  const isMobile = useMediaQuery("(max-width:600px)");
  const handleClick = () => {
    setOpen(!open);
  };
  const [drawerOpen, setDrawerOpen] = useState(false);

  const handleDrawerToggle = () => {
    setDrawerOpen(!drawerOpen);
  };

  return (
    // <div className="App">
    <Container >
      <Fab color="primary" aria-label="menu" onClick={handleDrawerToggle}>
        <MenuIcon />
      </Fab>
      {/* <AppBar position="static">
  <Toolbar>
    <IconButton
      edge="start"
      color="inherit"
      aria-label="menu"
      onClick={handleDrawerToggle}
    >
      <MenuIcon />
    </IconButton>
    <Typography variant="h6">Title</Typography>
  </Toolbar>
</AppBar> */}

      <Drawer
        variant={isMobile ? "temporary" : "permanent"}
        open={!isMobile || drawerOpen}
        onClose={handleDrawerToggle}
        style={{ position: "absolute", top: "64px" }}
      >
        <List>
          <ListItem button>
            <ListItemText primary="Chapter 1" />
          </ListItem>

          <ListItem button onClick={handleClick}>
            <ListItemText primary="Chapter 2" />
          </ListItem>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <List component="div" disablePadding>
              <ListItem button>
                <ListItemText primary="Sub-chapter 2.1" />
              </ListItem>
              <ListItem button>
                <ListItemText primary="Sub-chapter 2.2" />
              </ListItem>
            </List>
          </Collapse>

          <ListItem button>
            <ListItemText primary="Chapter 3" />
          </ListItem>
        </List>
      </Drawer>
    </Container>
    // </div>
  );
}

export default HomePage;
