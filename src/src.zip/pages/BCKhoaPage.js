import React from "react";

function BCKhoaPage() {
  return (
    <div>
      <h1>BCKhoaPage</h1>
    </div>
  );
}

export default BCKhoaPage;
