import React from "react";

function NotFoundPage() {
  return (
    <div>
      <h1>NotFoundPage</h1>
    </div>
  );
}

export default NotFoundPage;
