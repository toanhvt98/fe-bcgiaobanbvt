import React from "react";

function AdminPage() {
  return (
    <div>
      <h1>AdminPage</h1>
    </div>
  );
}

export default AdminPage;
